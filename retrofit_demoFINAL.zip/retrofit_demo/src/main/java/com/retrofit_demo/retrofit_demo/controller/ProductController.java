package com.retrofit_demo.retrofit_demo.controller;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.retrofit_demo.retrofit_demo.builder.Blueprint;
import com.retrofit_demo.retrofit_demo.model.Product;
import com.retrofit_demo.retrofit_demo.service.ProductService;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

import java.util.List;

@RestController
@RequestMapping("/products/")
public class ProductController implements Callback<List<Product>> {

    @GetMapping("")
    public void start() {
        Call<List<Product>> call = Blueprint.createService(ProductService.class).getProducts();/*productService.getProducts(); bilo pre Blueprinta*/
        call.enqueue(this);  // ovo radi sve umesto gornjih linija
    }                               // radi jer je /products/ .permitAll()

    @GetMapping("proba")
    public void getTopProducts(){
        Call<List<Product>> call = Blueprint.createService(ProductService.class).getTopProducts();
        call.enqueue(this);     // VAZNO -> nece raditi jer nema permit u configu app
    }


    @Override
    public void onResponse(Call<List<Product>> call, Response<List<Product>> response) {
        if(response.isSuccessful()) {
            List<Product> changesList = response.body();
            changesList.forEach(change -> System.out.println(change.getName()));
        } else {
            System.out.println(response.errorBody() + " doslo je do greske");
        }
    }


    public void onResponseForObject(Call<Product> call, Response<Product> response) {
        if(response.isSuccessful()) {
            var object = response.body();
            System.out.println(object);
        } else {
            System.out.println(response.errorBody() + " doslo je do greske");
        }
    }


    @Override
    public void onFailure(Call<List<Product>> call, Throwable t) {
        t.printStackTrace();
    }

    @GetMapping("test")
    public String printTest(){
        return "test";
    }
}
//    static final String BASE_URL = "http://localhost:8080"; treba da stoji iznad start() metode
  /* Gson gson = new GsonBuilder()
                .setLenient()
                .create();
        Retrofit retrofit = new Retrofit.Builder()
                .baseUrl(BASE_URL)
                .addConverterFactory(GsonConverterFactory.create(gson))
                .build();
        ProductService productService = retrofit.create(ProductService.class);

        ovo resava Blueprint klasa i metode*/



  /* Response<List<Product>> response;
        try {
            response = call.execute();
            List<Product> product = response.body();
        } catch (Exception e) {
            throw new RuntimeException("doslo je do greske");
        }
        Throwable t = new Throwable();
        onResponse(call, response);*/
//        onFailure(call, t);                   call.enqueue radi mesto svega ovoga

