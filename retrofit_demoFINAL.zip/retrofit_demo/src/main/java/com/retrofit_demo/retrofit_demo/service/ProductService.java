package com.retrofit_demo.retrofit_demo.service;

import com.retrofit_demo.retrofit_demo.model.Product;
import retrofit2.Call;
import retrofit2.http.GET;
import retrofit2.http.Path;
import retrofit2.http.Query;

import java.util.List;

public interface ProductService {

    @GET("products/")                  // ovo gadja api druge app
    Call<List<Product>> getProducts();
    @GET("products/topProducts")
    Call<List<Product>> getTopProducts();

    @GET("products/{id}")
    Call<Product> getProductsById(@Path("id") int id);

}
