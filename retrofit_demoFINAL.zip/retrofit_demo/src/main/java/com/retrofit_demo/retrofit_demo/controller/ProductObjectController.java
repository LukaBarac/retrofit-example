package com.retrofit_demo.retrofit_demo.controller;

import com.retrofit_demo.retrofit_demo.model.Product;
import org.springframework.web.bind.annotation.RestController;

import javax.security.auth.callback.Callback;
@RestController
public class ProductObjectController implements Callback<Product> {
}
