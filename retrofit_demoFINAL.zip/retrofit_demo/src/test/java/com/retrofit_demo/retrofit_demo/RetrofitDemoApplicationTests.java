package com.retrofit_demo.retrofit_demo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RetrofitDemoApplicationTests {

	@Test
	void contextLoads() {
	}

}
