package com.retrofit_demo.retrofit_demo.dto;

import lombok.Data;

@Data
public class CityDto {

    private String name;
    private int quantity;
    private double income;
}