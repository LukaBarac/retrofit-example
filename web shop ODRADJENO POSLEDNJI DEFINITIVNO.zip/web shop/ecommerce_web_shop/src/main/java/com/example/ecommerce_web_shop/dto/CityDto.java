package com.example.ecommerce_web_shop.dto;

public record CityDto(String name, int quantity, double income) {
}
