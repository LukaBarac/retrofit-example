package com.example.ecommerce_web_shop;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EcommerceWebShopApplication {

	public static void main(String[] args) {
		SpringApplication.run(EcommerceWebShopApplication.class, args);
	}

}
