package com.example.ecommerce_web_shop.service;

import com.example.ecommerce_web_shop.dto.RoleDto;

public interface RoleService {

    RoleDto saveRole(RoleDto roleDto);
}
