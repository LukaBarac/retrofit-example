package com.example.ecommerce_web_shop.exception;

public class BadRequestException extends RuntimeException{
    public BadRequestException(String message){super(message);}
}
