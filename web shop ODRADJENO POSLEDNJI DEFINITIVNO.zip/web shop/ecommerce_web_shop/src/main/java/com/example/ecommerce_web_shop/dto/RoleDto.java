package com.example.ecommerce_web_shop.dto;


public record RoleDto(String name) {

}
