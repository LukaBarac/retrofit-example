package com.example.ecommerce_web_shop.model;

public interface ProductReport {

    String getProductName();

    Double getProductPrice();
}
