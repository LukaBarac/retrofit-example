package com.example.ecommerce_web_shop.enums;

public enum ProductStockStatus {

    IN_STOCK, OUT_OF_STOCK
}
