package com.example.ecommerce_web_shop;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EcommerceWebShopApplicationTests {

	@Test
	void contextLoads() {
	}

}
