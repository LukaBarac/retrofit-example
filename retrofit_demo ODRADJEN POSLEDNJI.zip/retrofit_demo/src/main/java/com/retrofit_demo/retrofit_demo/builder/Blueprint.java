package com.retrofit_demo.retrofit_demo.builder;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class Blueprint {

        private final static String BASE_URL = "http://localhost:8080/";  // stavio final jer je intellij sugest.
        private final static Gson GSON = new GsonBuilder() //capslock zbog 'konvencije'
                .setLenient()
                .create();
        private final static Retrofit RETROFIT = new Retrofit.Builder()
                .baseUrl(BASE_URL)
                .addConverterFactory(GsonConverterFactory.create(GSON))
                .build();
        public static <S> S createService(Class<S> serviceClass) {
            return RETROFIT.create(serviceClass);
        }




}
